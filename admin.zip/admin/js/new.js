var g_userid;
var b_userid=false;
var g_pwd;
var b_pwd=false;
var g_username;
var perfect=false;
var g_admin=false;
function on_userid_blur(thisid) {
    var v_userid=document.getElementById(thisid).value;
    var flag=true;
    if(v_userid!="")
    {

        for(var i=0;i<localStorage.length;i++)
        {
            var data = JSON.parse(localStorage.getItem(localStorage.key(i)));
            if( data.userid==v_userid)
            {
                document.getElementById("id-span-userid").innerText="this id has exited";
                flag=false;
            }
        }
        if(flag)
        {
            var rec=/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,5-9]))\d{8}$/;//用户名满足电话号码13、14、15、18开头
            if(rec.test(v_userid)) {
                g_userid = v_userid;
                b_userid = true;
                document.getElementById("id-span-userid").innerText = "";
            }
            else
            {
                document.getElementById("id-span-userid").innerText = "input the valid number";
                b_userid=false;
            }
        }
    }
    else
    {
        document.getElementById("id-span-userid").innerText=" please enter your id";
        b_userid=false;
    }
    validate_all_info();
}
function on_pwd_blur(thisid) {
    var v_pwd=document.getElementById(thisid).value;
    if(v_pwd=="")
    {
        document.getElementById("id-span-pwd").innerText=" please enter password";
        b_pwd=false;
    }
    else
    {
        var rec=/^[\w_-]{6,16}$/;
        if(rec.test(v_pwd))
        {
            document.getElementById("id-span-pwd").innerText="";
        }
        else
        {
            document.getElementById("id-span-pwd").innerText="input the valid password";
            b_pwd=false;
        }
    }
    validate_all_info();
}
function on_repwd_blur(thisid,idpwd) {
var v_pwd=document.getElementById(idpwd).value;
var v_repwd=document.getElementById(thisid).value;
if(v_pwd==v_repwd&&v_pwd!="")
{
    document.getElementById("id-span-repwd").innerText="the same password";
    g_pwd=v_pwd;
    b_pwd=true;
}
else
{
    b_pwd=false;
    document.getElementById(idpwd).value="";
    document.getElementById(thisid).value="";
    document.getElementById("id-span-pwd").innerText=" please re-enter password";
    document.getElementById("id-span-repwd").innerText="enter the same word";
}
validate_all_info();
}
function on_username_blur(thisid) {
    var v_username=document.getElementById(thisid).value;
    if(v_username!="")
    {
        var rec=/^[a-zA-Z0-9\u4E00-\u9FA5]{1,12}$/;
        if(rec.test(v_username)) {
            g_username = v_username;
            document.getElementById("id-span-username").innerText = "a nice name";
        }
        else
        {
            document.getElementById("id-span-username").innerText="input the valid name";
            document.getElementById(thisid).value="";
        }
    }
    else
    {
        document.getElementById("id-span-username").innerText="a default name";
        g_username=Math.floor((Math.random()*100)+1)+"号顾客";
        //版本不同所以此处要为value
        document.getElementById(thisid).value=g_username;
    }
    validate_all_info();
}
function on_div() {
    //div标签中的文本内容属性不为空时触发
    if(document.getElementById("msg").textContent!="")
    {
        perfect=true;//验证成功
    }
    else
        perfect=false;
    validate_all_info();
}
function validate_all_info() {
    var b_valid=false;
    if(b_userid&&b_pwd&&perfect)
    {
        document.getElementById("id-span-submit").innerText="all right";
        document.getElementById("id-submit").removeAttribute("disabled");
    }
    else
    {
        document.getElementById("id-span-submit").innerText="check your info";
        document.getElementById("id-submit").setAttribute("disabled","disabled");
    }
    return b_valid;
}
function on_new_submit() {
    var person={};
    person.userid=g_userid;
    person.name=g_username;
    //结构体
    var u_new_user={};
    u_new_user.userid=g_userid;
    u_new_user.pwd=g_pwd;
    if(g_username==undefined)
        g_username=Math.floor((Math.random()*100)+1)+"号顾客";//用户若不填写用户名，则随机给一个名字
    u_new_user.name=g_username;
    u_new_user.adimin=g_admin;//用户权限true 为管理员
    localStorage.setItem(u_new_user.userid,JSON.stringify(u_new_user));

    sessionStorage.setItem("currentid",JSON.stringify(person));//内部含有多属性
    alert("注册成功");
}
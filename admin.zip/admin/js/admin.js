<!--其他元素加载完毕时执行-->
window.onload =function app() {
    var no=0;
    //同commodity.js
    document.getElementById("id-user-info").innerHTML =
        "<tr>"+
        "<th>"+"No."+"</th>"+
        "<th>"+"userid"+"</th>"+
        "<th>"+"pwd"+"</th>"+
        "<th>"+"name"+"</th>"+
        "<th>"+"identity"+"</th>"+
        "<th>"+"address"+"</th>"+
        "</tr>";
    for(var i=0;i<localStorage.length;i++)
    {
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        var rec=/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,5-9]))\d{8}$/;//只显示合法用户的信息
        if(!rec.test(localStorage.key(i))) {
            continue;
        }
        no+=1;
        var uid=data.userid;
        var pwd="******";//隐藏密码
        if (data.name.length>6)
            var name=data.name.slice(0,2)+"**"+data.name.slice(-3,-1);//只显示前两位和后两位
        else
            var name=data.name;
        if(data.identity==undefined)//对于未填写的undefined属性统一显示为“未填写”
        {
            var identity="未填写";
        }
        else
        {
            if (data.identity.length>6)
                var identity=data.identity.slice(0,2)+"**"+data.identity.slice(-3,-1);
            else
                var identity=data.identity;
        }
        if(data.address==undefined)
        {
            var address="未填写";
        }
        else
        {
            if (data.address.length>6)
                var address=data.address.slice(0,3)+"...";//显示地址的前三个字符，其余的用...代替
            else
                var address=data.address;
        }
        //在表格中添加html语句
        document.getElementById("id-user-info").innerHTML+=
            "<tr>"+
            "<td>"+no+"</td>"+
            "<td>"+uid+"</td>"+
            "<td>"+pwd+"</td>"+
            "<td>"+name+"</td>"+
            "<td>"+identity+"</td>"+
            "<td>"+address+"</td>"+
            "</tr>";
    }
    }
    function  on_commodity() {//点击不同按钮跳转至不同页面
        document.getElementById("id-form").setAttribute("action","commodity.html");
    }
    function on_order() {
        document.getElementById("id-form").setAttribute("action","order.html");
    }
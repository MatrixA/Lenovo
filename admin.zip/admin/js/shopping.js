var g_number;//商品数量
var g_image;//商品图片
var  g_kind;//商品种类
var g_text;//商品描述
var g_commodity;//商品编号
var g_money;
var g_userid;
var g_userids;
var b_userid=true;
var g_username;
var b_username=true;
var g_identity;
var b_identity=false;
var g_address;
var b_address=false;
var sum=0;
//用户id和下单时间才是key
window.onload=function () {
    //获取当前登录的用户
    var ids = JSON.parse(sessionStorage.getItem("currentid")).userid;
    g_userid="%"+ids;
    g_userids=ids;
    for(var i=0;i<localStorage.length;i++)
    {
        if(g_userid==localStorage.key(i))
        {
            var data=JSON.parse(localStorage.getItem(g_userid));
            g_username=data.name;
            if(data.identity==undefined)
                g_identity="";
            else
            {
                g_identity=data.identity;
                b_identity=true;
            }
            if(data.address==undefined)
            {
                g_address="";
            }
            else
                {
                    g_address=data.address;
                    b_address=true;
                }
           if (data.number!=undefined)
           {
               g_number=data.number;
           }
            else
               g_number={};
            if(data.image!=undefined)
                g_image=data.image;
            else g_image={};
            if(data.kind!=undefined)
            {
                g_kind=data.kind;
            }
            else g_kind=0;
            if(data.money!=undefined)
                g_money=data.money;
            else g_money={};
            if(data.text!=undefined)
                g_text=data.text;
            else g_text={};
            if(data.commodity!=undefined)
                g_commodity=data.commodity;
            else g_commodity={};
             g_all={};
            for(var j=0;j<g_kind;j++) {

                //在表格中填写以下信息
               document.getElementById("id-table").innerHTML +=
                   "<tr >"+
                    "<td class='td-right'>"+
                    "<img class='img' id='"+"i"+j+"' src="+g_image[j]+"  alt='"+i+"'件商品图片'>"+
                    "<td>"+
                    "<textarea id='"+"t"+j+"'  rows='3' cols='28'  readonly>"+g_text[j]+"</textarea>"+
                "</td>"+
                "<td >"+
                "<table cellspacing='0' cellpadding='4' style='border-collapse: collapse;'>"+
                    "<tr>"+
                    "<td width='50px'>"+
                    "<button  type='button' onclick='on_subtract("+j+")'style='height: 35px;width:20px;margin:0px 0px;padding-left:0px; padding-right:0px'>"
                    +"-"+"</button>"+
                    "</td>"+
                    "<td>"+
                    "<h4 id='"+"h"+j+"' style='width: 130px'>"+"数量:"+g_number[j]+"件"+"</h4>"+
                "</td>"+
                "<td>"+
                "<button type='button' onclick='on_multiply("+j+")'style=' height: 35px;width:20px;margin:0px 0px;padding-left:0px;padding-right:0px ' >"
                    +"+"+"</button>"+
                    "</td>"+
                   "</tr>"+
                   "</table>"+
                   "</td>"+
                   "</tr>"
                sum+=g_number[j]*g_money[j];
               //移动到下方，防止标签页后续改动诗赋值失效。
                document.getElementById("id-userid").value=g_userids;
                document.getElementById("id-username").value=g_username;
                document.getElementById("id-identity").value=g_identity;
                document.getElementById("id-address").value=g_address;
            }
            validate_all_info();
            break;
        }
        else
        {
            var u=JSON.parse(localStorage.getItem(ids));
            document.getElementById("id-userid").value=u.userid;
            document.getElementById("id-username").value=u.username;
            document.getElementById("id-identity").value=u.identity;
            document.getElementById("id-address").value=u.address;
        }
    }
    document.getElementById("id-money").innerText="总价:"+sum+"元";
}
function on_username_blur(thisid) {
    var v_username=document.getElementById(thisid).value;
    if(v_username!="")
    {
        b_username=true;
    }
    else
    {
        document.getElementById("id-span-username").innerText="can't get your username";
        b_username=false;
    }
    validate_all_info();
}

function on_identity_blur(thisid) {
    var v_identity=document.getElementById(thisid).value;
    if(v_identity!="")
    {
        b_identity=true;
    }
    else{
        document.getElementById('id-span-identity').innerHTML="can't get your id";
        b_identity=false;
    }
    validate_all_info();
}

function on_address_blur(thisid) {
    var v_address=document.getElementById(thisid).value;
    if(v_address!="")
    {
        b_address=true;
    }
    else{

        document.getElementById('id-span-address').innerHTML="can't get your address";
        b_address=false;
    }
    validate_all_info();
}
function on_multiply(kin) {//计算总价钱
    if(g_number[kin]>=10)
    {
        alert("已达添加上限");
        g_number[kin]--;
    }
    g_number[kin]++;
    sum+=parseInt(g_money[kin]);//money数组被当成字符串了，需要类型转换
    document.getElementById("h"+kin).innerText="数量:"+g_number[kin]+"件";//对应id标签的数量变化
    document.getElementById("id-money").innerText="总价:"+sum+"元";
}
function on_subtract(kin) {
    if(g_number[kin]>0)
    {
        g_number[kin]--;
        sum-=parseInt(g_money[kin]);
    }
    document.getElementById("h"+kin).innerText="数量:"+g_number[kin]+"件";
    document.getElementById("id-money").innerText="总价:"+sum+"元";
    if(g_number[kin]==0)
    {
        var u_admin={};
        u_admin.userid=g_userid;//记录该用户购物车里的物品,静态存储。和记录当前登录用户的临时存储相区别
        u_admin.name=g_username;
        u_admin.identity=g_identity
        u_admin.address=g_address;
        u_admin.kind=0;
        u_admin.number={};
        u_admin.commodity={};
        u_admin.image={};
        u_admin.text={};
        u_admin.money={};
        for(var i=0;i<g_kind;i++) {
            if(g_number[i]==0)
                continue;
            u_admin.image[u_admin.kind]=g_image[i];
            u_admin.text[u_admin.kind]=g_text[i];
            u_admin.money[u_admin.kind]=g_money[i];
            u_admin.commodity[u_admin.kind]=g_commodity[i];
            u_admin.number[u_admin.kind]=g_number[i];
            u_admin.kind++;
        }
        localStorage.setItem(u_admin.userid,JSON.stringify(u_admin));
        location.reload();
    }
}

function validate_all_info() {
    var b_valid=false;
    if(b_username&&b_address&&b_identity&&b_userid)
    {
        b_valid=true;
        document.getElementById("id-submit").removeAttribute("disabled");
    }
    else
    {
        document.getElementById("id-span-submit").innerText="fill your information";
        document.getElementById("id-submit").setAttribute("disabled","disabled");
    }
    return b_valid;
}
function on_shop_submit() {
    var myDate = new Date();
    var t=myDate.getFullYear().toString()+(myDate.getMonth()+1).toString()+myDate.getDate().toString()+myDate.getHours().toString()+myDate.getMinutes().toString()+myDate.getSeconds().toString();
    var u_shop_user={};
    u_shop_user.commodity=g_commodity;//商品编号数组
    u_shop_user.text=g_text;//商品文字描述数组
    u_shop_user.state=0;//订单状态
    u_shop_user.number=g_number;//商品数量数组
    u_shop_user.time=t;//下单时间
    u_shop_user.userid=g_userids;
    u_shop_user.name=g_username;
    u_shop_user.identity=g_identity;
    u_shop_user.address=g_address;
    u_shop_user.sum=sum;
    for(var i=0;i<g_kind;i++)
    {
        var goods=JSON.parse(localStorage.getItem(g_commodity[i]));
        var newgoods={};
        newgoods.goodsid=goods.goodsid;
        newgoods.money=goods.money;
        newgoods.all=parseInt(goods.all)- parseInt(g_number[i]);
        newgoods.text=goods.text;
        newgoods.image=goods.image;
        localStorage.setItem(newgoods.goodsid,JSON.stringify(newgoods));//
    }
    //其中[]最终为字符串类型
    localStorage.setItem([u_shop_user.userid,u_shop_user.time],JSON.stringify(u_shop_user));//两个属性为一个数组建立主键
    localStorage.removeItem(localStorage.key(g_userid));//移除购物车键值对，添加到
    alert("下单成功");
    window.history.back(-1);//回退历史，返回上一个页面
}
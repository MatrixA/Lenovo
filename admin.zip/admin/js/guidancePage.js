var record={};
window.onload =function app() {
    var ids =JSON.parse(sessionStorage.getItem("currentid"));
    if(ids!=undefined)
    {
        document.getElementById("id-a").innerText=ids.name;
    }

    var sum=0;
    var kinds=0;
    var flag=false;
    var admin=document.getElementById("id-a").innerText;
    if(admin!="登录") {
        var u_id = JSON.parse(sessionStorage.getItem("currentid")).userid;
        var datas = JSON.parse(localStorage.getItem(u_id));
        var u_purchase = {};
        u_purchase.userid = "%" + datas.userid;
        u_purchase.name = datas.name;
        u_purchase.identity = datas.identity;
        u_purchase.address = datas.address;
        var own = JSON.parse(localStorage.getItem(u_purchase.userid));
        if (own == undefined) {
            kinds = 1;
            sum=0;
        }
        else {
            kinds = own.kind;
            for (var l = 0; l < kinds; l++) {
                sum += own.number[l];
            }
        }
        document.getElementById("id-buy").innerText = "购物车：" + sum + "件";
    }

    var j=0;
    var num={};
    for(var i=0;i<localStorage.length;i++)
    {
        var keyer=localStorage.key(i);
        if(keyer.indexOf("_")==(-1))
        {
            continue;
        }
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        num[j]=parseInt(data.all);
        record[j]=i;
        j++;
    }//j=4
    var t=0;
    for(var k=0;k<j-1;k++)
    {
        for(var l=k+1;l<j;l++)
        {
            if(num[l]>num[k])
            {

                t=num[l];
                num[l]=num[k];
                num[k]=t;
                t=record[l];
                record[l]=record[k];
                record[k]=t;
            }
        }
    }
    for(var i=0;i<4;i++)
    {
        var data=JSON.parse(localStorage.getItem(localStorage.key(record[i])));
        document.getElementById("product").innerHTML +="<div  id="+i+"  class = 'item' onclick='on_item(this.id);' >" +
            "<img  src="+data.image+" width='100%'height='100%'>"+ "</div>"+
            "<div class = 'item'>" +"商品型号 — —"+"<br>"+data.goodsid+"<br><br>"+
            "<span id='span'>"+"售价：¥"+data.money+"</span>"+"<br>"+"<br>"+"商品配置 — —"+"<br>"+data.text+"</div>"
    }
/*<
        <div class = 'item'>
        </div>*/
}
function on_shopping() {
    var ids =JSON.parse(sessionStorage.getItem("currentid"));
    if(ids==undefined)
    {
        alert("游客模式，请先登录");
    }
    else
    {
        location.href="shopping.html";
    }
}
function  on_item(thisid) {
    var data=JSON.parse(localStorage.getItem(localStorage.key(record[thisid])));
    sessionStorage.setItem("good",JSON.stringify(data));
    location.href="item.html";
}
function on_search(thisid) {
    var series_goods;
    series_goods=document.getElementById(thisid).textContent;//获取文本内容
    sessionStorage.setItem("series",series_goods);
}
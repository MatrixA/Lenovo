<!--其他元素加载完毕时执行-->
window.onload =function app() {
    var no=0;
    document.getElementById("id-user-info").innerHTML =
        "<tr>"+
        "<th>"+"订单号"+"</th>"+//订单号没有实际意义，可以删除
        "<th>"+"用户电话"+"</th>"+
        "<th>"+"用户名"+"</th>"+
        "<th>"+"下单时间"+"</th>"+
        "<th>"+"地址"+"</th>"+
        "<th>"+"订单状态"+"</th>"+
        "</tr>";
    for(var i=0;i<localStorage.length;i++)
    {
        var keyer=localStorage.key(i);
        if(keyer.indexOf(",")==(-1))
        {
            continue;
        }
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        no+=1;
        var uid=data.userid;
        var name=data.name;
        var time=data.time;
        if(data.address==undefined)
        {
            var address="未填写";
        }
        else
        {
            var address=data.address;
        }
        if(data.state==undefined)
            state=0;
        else
            var state=data.state;
        document.getElementById("id-user-info").innerHTML+=
            "<tr>"+
            "<td>"+no+"</td>"+
            "<td>"+uid+"</td>"+
            "<td>"+name+"</td>"+
            "<td>"+time+"</td>"+
            "<td>"+address+"</td>"+
            "<td>"+ "<select id="+no+"> "+"<option>"+0+"</option>" +"<option>"+1+"</option>"+ "<option>"+2+"</option>"+ "</select>"//选择当前订单状态
            "</td>"+
            "</tr>";
        document.getElementById(no)[state].selected=true;//设置对应订单默认状态为所存储的状态
    }
}
function on_shop_submit() {
    var no=0;
    for(var i=0;i<localStorage.length;i++)
    {
        var keyer=localStorage.key(i);
        if(keyer.indexOf(",")==(-1))
        {
            continue;
        }
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        no+=1;
        if(document.getElementById(no).value==2)//将交易完成的订单移除或交给售后
        {
            localStorage.removeItem(localStorage.key(i));
            continue;
        }
        var user={};
        user.userid=data.userid;//用户手机
        user.goodsid=data.goodsid;//商品编号
        user.text=data.text;//商品描述
        user.state=document.getElementById(no).value;//订单状态
        user.number=data.number;//商品数量
        user.time=data.time;//下单时间
        user.name=data.name;//用户姓名
        user.identity=data.identity;//用户身份证
        user.address=data.address;//用户地址
        localStorage.setItem([user.userid,user.time],JSON.stringify(user));//两个属性为一个数组建立主键
        window.history.back(-1);//返回上一个页面
    }
}
var series;
var scale;
var year;
var colors;
var category;
var ids;
var money;
var all;
var num=1;
var coreimage;
var texts;
var intel;
var navi;
var rand;
$(document).ready(function() {
    var user =JSON.parse(sessionStorage.getItem("currentid"));
    if(user!=undefined)
    {
        document.getElementById("id-a").innerText=user.name;
    }
    var good =JSON.parse(sessionStorage.getItem("good"));
    if(good ==undefined)
    {
        alert("错误...自动跳转至商城");
        location.href="index.html";
    }
    if(good.goodsid.slice(0,1)=="Z")
    {
        series="拯救者";
        category="游戏本";
    }
    else if (good.goodsid.slice(0,1)=="Y")
    {
        series="游侠";
        category="专业本";
    }
    else  if(good.goodsid.slice(0,1)=="X")
    {
        series="小新";
        category="家庭本";
    }
    else  if(good.goodsid.slice(0,1)=="E")
    {
        series="二合一";
        category="商务本";
    }
    else  if(good.goodsid.slice(0,1)=="A")
    {
        series="主机";
        category="游戏主机";
    }
    else  if(good.goodsid.slice(0,1)=="B")
    {
        series="一体机";
        category="专业一体机";
    }
    else  if(good.goodsid.slice(0,1)=="C")
    {
        series="显示器";
        category="专业显示器";
    }
    else series="空";
    year="20"+good.goodsid.slice(1,3)+"年爆款";
    scale="1"+good.goodsid.slice(4,5)+"英寸";
    colors=good.goodsid.slice(5,6);
    if(colors=="B")
        colors="黑";
    else
        colors="白";
    norm=good.goodsid.slice(6,7);
    if(norm=="N")
        norm="非触屏";
    else norm="触屏";
    intel="酷睿 i"+good.goodsid.slice(8,9);
    navi="英伟达 GTX10"+good.goodsid.slice(10,12);
    rand=good.goodsid.slice(13,15)+"g";
    ids=good.goodsid;
    money=good.money;
    all=good.all;
    document.getElementById("id-goodsid").innerText=ids;
    document.getElementById("id-series").innerText=series;
    texts=series+" "+ids+" "+year+"\n"+scale+" "+category+" "+colors+"\n"+intel+" "+navi+" "+rand;
    document.getElementById("id-text").innerText=texts;
    document.getElementById("id-money").innerText=money;
    if(all>5)
        document.getElementById("id-all").innerText="库存（"+all+"）";
    else
        document.getElementById("id-all").innerText="缺货！";
    document.getElementById("min").setAttribute("disabled","disabled");

    coreimage="goodsImg/"+ids.slice(0,6)+".jpg";
    for(var i=0;i<6;i++)
    {
        var img="images/photos/"+ids.slice(0,6)+(i+1)+".jpg";
        document.getElementById("showbox").innerHTML += " <img src=" + img + " width='400' height='400' >";
    }

    document.getElementById("goods-name").innerText+=series+category;
    document.getElementById("goods-commodity").innerText+=ids;
    document.getElementById("goods-year").innerText+=year;
    document.getElementById("goods-weight").innerText+=(10+parseInt(good.goodsid.slice(4,5)))*2/10+"kg";
    document.getElementById("goods-all").innerText+=all;
    document.getElementById("goods-image").innerHTML+="<img src="+coreimage+">";
    for(var i=0;i<5;i++)
    {
        var show="images/photos/"+ids.slice(0,6)+"-0"+(i+1)+".jpg";
        document.getElementById("goods-show").innerHTML += " <img src=" + show + " >";
    }
        // 任何需要执行的js特效

    var sum=0;
    var kinds=0;
    var flag=false;
    var admin=document.getElementById("id-a").innerText;
    if(admin!="登录") {
        var u_id = JSON.parse(sessionStorage.getItem("currentid")).userid;
        var datas = JSON.parse(localStorage.getItem(u_id));
        var u_purchase = {};
        u_purchase.userid = "%" + datas.userid;
        u_purchase.name = datas.name;
        u_purchase.identity = datas.identity;
        u_purchase.address = datas.address;
        var own = JSON.parse(localStorage.getItem(u_purchase.userid));
        if (own == undefined) {
            kinds = 1;
            sum=0;
        }
        else {
            kinds = own.kind;
            for (var l = 0; l < kinds; l++) {
                sum += own.number[l];
            }
        }
        document.getElementById("id-buy").innerText = "购物车：" + sum + "件";
    }

    $("table tr:nth-child(even)").addClass("even");

});

function on_mul(thisid) {
    num=document.getElementById("text_box").value;
    if(num>=9)
    {
        alert("已达购买上限！");
        document.getElementById(thisid).setAttribute("disabled","disabled");
    }
    else if(num>=all-1)
        {
            alert("库存不足!");
            document.getElementById(thisid).setAttribute("disabled","disabled");
        }
    document.getElementById("min").removeAttribute("disabled");
        num++;
    document.getElementById("text_box").value=num;
    document.getElementById("id-money").innerText=num*money;
}
function on_sub(thisid) {
    num=document.getElementById("text_box").value;
    if(num<=2)
    {
        document.getElementById(thisid).setAttribute("disabled","disabled");
    }
    document.getElementById("max").removeAttribute("disabled");
    num--;
    document.getElementById("text_box").value=num;
    document.getElementById("id-money").innerText=num*money;
}
function on_add(ff) {
    var flag=false;
    var admin=document.getElementById("id-a").innerText;
    if(admin=="登录")
    {
        alert("请先登录！");
    }
    else
    {
        var u_id=JSON.parse(sessionStorage.getItem("currentid")).userid;
        var data=JSON.parse(localStorage.getItem(u_id));
        var u_purchase={};
        u_purchase.userid="%"+data.userid;
        u_purchase.name=data.name;
        u_purchase.identity=data.identity;
        u_purchase.address=data.address;
        var own=JSON.parse(localStorage.getItem(u_purchase.userid));
        if(own==undefined)
        {
            u_purchase.kind=1;
            u_purchase.number={};
            u_purchase.commodity={};
            u_purchase.image={};
            u_purchase.text={};
            u_purchase.money={};
            u_purchase.number[0]=parseInt(num);
            u_purchase.commodity[0]=ids;
            u_purchase.image[0]=coreimage;
            u_purchase.text[0]=texts;
            u_purchase.money[0]=money;
        }
        else
        {
            u_purchase.kind=own.kind;
            u_purchase.number=own.number;
            u_purchase.commodity=own.commodity;
            u_purchase.image=own.image;
            u_purchase.text=own.text;
            u_purchase.money=own.money;
                for (var i = 0; i < own.kind; i++) {
                    if (ids == own.commodity[i]) {
                        flag = true;
                        break;
                    }
                }
                if (flag) {

                    u_purchase.number[i] =parseInt(u_purchase.number[i]) +parseInt(num);
                    u_purchase.money[i]  =parseInt(money);
                }
                else {
                    u_purchase.kind++;
                    u_purchase.number[i] = parseInt(num);
                    u_purchase.commodity[i] = ids;
                    u_purchase.image[i]=coreimage;
                    u_purchase.text[i] = texts;
                    u_purchase.money[i] = parseInt(money);
                }

        }
        var sum=0;
        for(var l=0;l<u_purchase.kind;l++)
        {
            sum+=u_purchase.number[l];
        }
        localStorage.setItem(u_purchase.userid,JSON.stringify(u_purchase));
        document.getElementById("id-buy").innerText="购物车："+sum+"件";
        if(ff)
            alert("已添加至购物车");
    }
}
function on_purchase() {
    var admin=document.getElementById("id-a").innerText;
    if(admin=="登录")
    {
        alert("请先登录！");
    }
    else
    {
        on_add(0);
        alert("跳转至结算页面");
        location.href="shopping.html";
    }
}

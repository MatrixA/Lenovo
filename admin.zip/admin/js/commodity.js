<!--其他元素加载完毕时执行onload-->
var g_save=false;
window.onload =function app() {
    //向此id标签元素（表格）中覆盖如下html语句
    document.getElementById("id-user-info").innerHTML =
        "<tr>"+
        "<th>"+"商品编号"+"</th>"+//最好只读
        "<th>"+"商品图片"+"</th>"+
        "<th>"+"商品描述"+"</th>"+
        "<th>"+"商品库存"+"</th>"+
        "<th>"+"商品单价"+"</th>"+
        "</tr>";
    for(var i=0;i<localStorage.length;i++)
    {
        var keyer=localStorage.key(i);
        if(keyer.indexOf("_")==(-1))
        {
            continue;
        }
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        var goodsid=data.goodsid;
        var image=data.image;
        var text=data.text;
        var textid="t"+goodsid;
        var all=data.all;
        var allid="a"+goodsid;//字符串和数字相加转化成字符串
        var money=data.money;
        var moneyid="m"+goodsid;
        //向此id标签元素（表格）中添加如下html语句
        document.getElementById("id-user-info").innerHTML+=
            "<tr>"+
            "<td >"+ goodsid+
            "<button  type='button' class='good' onclick='on_delete("+i+")'style='left: 40px;height: 40px;width:100px;margin:0px 0px;padding-left:0px; padding-right:0px'>"+"delete"+"</button>"+
            "</td>"+
            "<td >"+"<img  class='img'onclick='on_goods(this.id)' src="+image+" >"+"</td>"+
            "<td>"+"<textarea id='"+textid+"'"+" rows='3' cols='28'>"+text+"</textarea>"+"</td>"+
            "<td>"+"<input type='text' class='goods' id='"+allid+ "' "+"value='"+all+"'>"+"</td>"+
            "<td>"+"<input type='text' class='goods' id='"+moneyid+ "' "+"value='"+money+"'>"+"</td>"+
        "</tr>";
    }
}
//提交时触发
function on_shop_submit() {
    if(g_save) {
        for (var i = 0; i < localStorage.length; i++) {
            var keyer = localStorage.key(i);
            if (keyer.indexOf("_") == (-1)) {
                continue;
            }//若键类型不符合，无_
            var data = JSON.parse(localStorage.getItem(localStorage.key(i)));
            var goods = {};
            goods.goodsid = data.goodsid;//商品编号（带有_）
            goods.image = data.image;//商品图片（url）
            goods.text = document.getElementById("t" + data.goodsid).value;//商品描述
            goods.all = document.getElementById("a" + data.goodsid).value;//商品库存
            goods.money = document.getElementById("m" + data.goodsid).value;//商品单价
            localStorage.setItem([goods.goodsid], JSON.stringify(goods));//商品编号为主键，建立键值对
        }
        alert("管理员大大~保存成功~");
        g_save=false;//置换回初值
    }
    else{
        location.reload();
    }
    //window.history.back(-1);//返回上一个页面
}
//删除商品时触发
function on_delete(thiskey) {
    if(confirm("确定要删除此商品？"))
    {
        localStorage.removeItem(localStorage.key(thiskey));//移除键值对
        alert("删除成功");
        location.reload();
    }
}
function on_save() {
    g_save=true;
}
function on_new() {
    document.getElementById("id-form").style.display="";
    document.getElementById("myCanvas").style.display="";
    return false;
}
function on_canvas() {
    //需要reset数据
    document.getElementById("id-form").reset();
    document.getElementById("id-form").style.display="none";
    document.getElementById("myCanvas").style.display="none";
}
function on_add() {
    var new_commodity={};
    new_commodity.goodsid=document.getElementById("id-add-goodsid").value;
    new_commodity.text=document.getElementById("id-add-text").value;
    new_commodity.all=document.getElementById("id-add-all").value;
    new_commodity.money=document.getElementById("id-add-money").value;
    new_commodity.image="goodsImg/"+document.getElementById("id-add-goodsid").value.slice(0,6)+".jpg";
    localStorage.setItem(new_commodity.goodsid,JSON.stringify(new_commodity));
    on_canvas();
    return true;//同样提交表单
}
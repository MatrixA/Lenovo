var modify=false;
var g_userid;
var b_userid=true;
var g_pwd;
var b_pwd=true;
var g_username;
var b_username=true;
var g_identity;
var b_identity=false;
var g_address;
var b_address=false;
window.onload=function () {
   var ids =JSON.parse(sessionStorage.getItem("currentid")).userid;//在临时存储数据库中找到当前登录的用户
   g_userid=ids;
   document.getElementById("id-userid").value=ids;//在此id标签（文本框）中赋值此用户id
   for(var i=0;i<localStorage.length;i++)
   {
       var data=JSON.parse(localStorage.getItem(localStorage.key(i)));//截取localstorage中第i条记录中的值字段
       if(ids==data.userid)//若此值字段中的userid属性与当前用户相匹配
       {
           g_username=data.name;
           g_pwd=data.pwd;
           if(data.identity==undefined)//若没填写相关信息，则对应值为空，否则为undefined
               g_identity="";
           else
               g_identity=data.identity;
           if(data.address==undefined)
               g_address="";
           else
           g_address=data.address;
           g_admin=data.admin;
           //将所有要展示的信息自动填好
           document.getElementById("id-username").value=g_username;
           document.getElementById("id-password").value=g_pwd;
           document.getElementById("id-repassword").value=g_pwd;
           document.getElementById("id-identity").value=g_identity;
           document.getElementById("id-address").value=g_address;
           alert("确认或修改您的个人信息");//提示语句
           break;//每用户只有一个账号，也只登录一个账号
       }
   }
}
function on_edit(thisid) {
    var cc=document.getElementById(thisid);
    if(cc.checked)//在没有点击“编辑开关”的时候，默认所有信息都是不可编辑的
    {
        document.getElementById("id-username").removeAttribute("disabled","disabled");
        document.getElementById("id-password").removeAttribute("disabled","disabled");
        document.getElementById("id-repassword").removeAttribute("disabled","disabled");
        document.getElementById("id-identity").removeAttribute("disabled","disabled");
        document.getElementById("id-address").removeAttribute("disabled","disabled");
    }
    else//点击开关后，也只有部分信息可以编辑，而用户手机号（即userid）不能始终编辑
    {
        document.getElementById("id-username").setAttribute("disabled","disabled");
        document.getElementById("id-password").setAttribute("disabled","disabled");
        document.getElementById("id-repassword").setAttribute("disabled","disabled");
        document.getElementById("id-identity").setAttribute("disabled","disabled");
        document.getElementById("id-address").setAttribute("disabled","disabled");
    }
}
function on_userid_blur(thisid) {//测试id是否获得
    var v_userid=document.getElementById(thisid).value;
    if(v_userid !="")
    {
        b_userid=true;
    }
    else
    {
        document.getElementById("id-span-userid").innerText="con't get your id";
        b_userid=false;//每次都进行统一验证
    }
    validate_all_info();
}
function on_pwd_blur(thisid){
    var v_pwd=document.getElementById(thisid).value;
    if(v_pwd==g_pwd&&v_pwd!="")//没有修改原密码时
    {
        document.getElementById("id-span-pwd").innerText=" you can modify your new password";
        b_pwd=true;
    }
    else if(v_pwd=="")
    {
        document.getElementById("id-span-pwd").innerText="please enter your password";
        b_pwd=false;
    }
    else
    {
        var rec=/^[\w_-]{6,16}$/;//密码需要符合正规式：6-16位字母数字特殊字符
        if(rec.test(v_pwd))
        {
            document.getElementById("id-span-pwd").innerText="";
        }
        else
        {
            document.getElementById("id-span-pwd").innerText="input the valid password";
            b_pwd=false;
        }
    }
    validate_all_info();
}
function on_repwd_blur(thisid,idpwd) {//第二次输入只需要和第一次完全相同即可
    var v_pwd=document.getElementById(idpwd).value;
    var  v_repwd=document.getElementById(thisid).value;
    if(v_pwd!=v_repwd)
    {
        document.getElementById("id-span-repwd").innerText="enter the same password please";
        b_pwd=false;
    }
    else if(v_pwd=="")
    {
        document.getElementById("id-span-repwd").innerText="please enter your password";
        b_pwd=false;
    }
    else
    {
        document.getElementById("id-span-repwd").innerText="";
        g_pwd=v_pwd;
        b_pwd=true;
    }
    validate_all_info();
}
function on_username_blur(thisid) {
    var v_username=document.getElementById(thisid).value;
    if(v_username!=g_username&&v_username!="")
    {
        var rec=/^[a-zA-Z0-9\u4E00-\u9FA5]{1,12}$/;//用户名需要满足正规式：1-12位字母数字特殊字符
        if(rec.test(v_username)) {
            g_username = v_username;
            b_username = true;
            document.getElementById("id-span-username").innerText = "a nice name";
        }
        else {
            document.getElementById("id-span-username").innerText = "input the valid name";
            b_username=false;
            document.getElementById(thisid).value=g_username;//只要用户名不满足规则都会改回默认值
        }
    }
    else if(v_username=="")
    {
        document.getElementById("id-span-username").innerText="please enter user name";
        b_username=false;
    }
    else
    {

        document.getElementById("id-span-username").innerText="";
        b_username=true;
    }
    validate_all_info();
}

function on_identity_blur(thisid) {
    var v_identity=document.getElementById(thisid).value;
    if(v_identity!=g_identity)
    {
        document.getElementById('id-span-identity').innerHTML="we can know you better";
        b_identity=true;
        g_identity=v_identity;
    }
    else if(v_identity=="")
        {
            document.getElementById('id-span-identity').innerHTML="fill your id please";
        }
        else
    {
        var rec=/^\d{15}(\d{2}[A-Za-z0-9])?$/ ;//身份证满足国家标准正规式
        if(rec.test(v_identity))
        {
            document.getElementById('id-span-identity').innerHTML="";
        }
        else
        {
            document.getElementById('id-span-identity').innerHTML="input the valid id";
            document.getElementById(thisid).value="";//不满足标准则被清空
        }
    }
    validate_all_info();
}

function on_address_blur(thisid) {//地址不需要满足正规式
    var v_address=document.getElementById(thisid).value;
    if(v_address!=g_address)
    {
        document.getElementById('id-span-address').innerHTML="we can send to you";
        b_address=true;
        g_address=v_address;
    }
    else if(v_address=="")
    {
        document.getElementById('id-span-address').innerHTML="fill your address please";
    }
    else{
        document.getElementById('id-span-address').innerHTML="";
    }
    validate_all_info();
}


function validate_all_info() {
    var b_valid=false;
    if(b_userid&&b_pwd &&(b_username||b_address||b_identity))//只有在基础信息都正确并且有改动才可以真正修改
    {
        b_valid=true;
        document.getElementById("id-span-submit").innerText="all right";
        document.getElementById("id-submit").removeAttribute("disabled");
    }
    else
    {
        document.getElementById("id-span-submit").innerText="check your info";
        document.getElementById("id-submit").setAttribute("disabled","disabled");
    }
    return b_valid;
}
function which_submit(thisid) {//是点击“已确认”按钮还是点击“保存修改按钮”
    if(thisid=="id-goshopping")
    {
        modify=false;
    }
    else
        modify=true;
}
function on_edit_submit() {
    if(modify) {//若修改了
        var u_edit_user = {};
        u_edit_user.userid = g_userid;
        u_edit_user.pwd = g_pwd;
        u_edit_user.name = g_username;
        u_edit_user.identity = g_identity;
        u_edit_user.address = g_address;
        u_edit_user.admin=g_admin
        localStorage.setItem(u_edit_user.userid, JSON.stringify(u_edit_user));
        alert("修改成功");
        location.reload();
    }
    else//若只是确认信息
    {
        alert("已核实信息，正跳转至商城...");
    }
}
var g_userid;
var b_userid=false;
var g_pwd;
var b_pwd=false;
var checkcode=false;
var coder;
var flag;
function on_userid_blur(thisid) {
    var v_userid=document.getElementById(thisid).value;
    if(v_userid!="")
    {
        var data = JSON.parse(localStorage.getItem(v_userid));
        if(data==undefined) {
            flag = false;
        }
        else
            flag=true;
        if (flag) {
            g_userid = v_userid;
            b_userid = true;
            document.getElementById("id-span-userid").innerText = "";
        }
        else{
            document.getElementById("id-span-userid").innerText = "input the right number";
        }
    }
    else
    {
        document.getElementById("id-span-userid").innerText=" please enter your id";
        b_userid=false;
    }
    validate_all_info();
}

function on_send() {
    coder="1234";
    alert(coder);
    return false;
}
function on_code_blur(thisid) {//检查验证码是否正确
    var v_check=document.getElementById(thisid).value;
    if(v_check==coder)
    {
        checkcode=true;
        document.getElementById("id-password").removeAttribute("disabled","disabled");
        document.getElementById("id-repassword").removeAttribute("disabled","disabled");
        document.getElementById("id-span-verify").innerText="";
    }
    else
    {
        checkcode=false;
        document.getElementById("id-span-verify").innerText="wrong code!";
        document.getElementById("id-password").setAttribute("disabled","disabled");
        document.getElementById("id-repassword").setAttribute("disabled","disabled");
    }
}
function on_pwd_blur(thisid) {
    var v_pwd=document.getElementById(thisid).value;
    if(v_pwd=="")
    {
        document.getElementById("id-span-pwd").innerText=" please enter password";
        b_pwd=false;
    }
    else
    {
        var rec=/^[\w_-]{6,16}$/;
        if(rec.test(v_pwd))
        {
            document.getElementById("id-span-pwd").innerText="";
        }
        else
        {
            document.getElementById("id-span-pwd").innerText="input the valid password";
            b_pwd=false;
        }
    }
    validate_all_info();
}
function on_repwd_blur(thisid,idpwd) {
    var v_pwd=document.getElementById(idpwd).value;
    var v_repwd=document.getElementById(thisid).value;
    if(v_pwd==v_repwd&&v_pwd!="")
    {
        document.getElementById("id-span-repwd").innerText="the same password";
        g_pwd=v_pwd;
        b_pwd=true;
    }
    else
    {
        b_pwd=false;
        document.getElementById(idpwd).value="";
        document.getElementById(thisid).value="";
        document.getElementById("id-span-pwd").innerText=" please re-enter password";
        document.getElementById("id-span-repwd").innerText="enter the same word";
    }
    validate_all_info();
}
function validate_all_info() {
    var b_valid=false;
    if(b_userid&&b_pwd&&checkcode)
    {
        document.getElementById("id-span-submit").innerText="all right";
        document.getElementById("id-submit").removeAttribute("disabled");
    }
    else
    {
        document.getElementById("id-span-submit").innerText="check your info";
        document.getElementById("id-submit").setAttribute("disabled","disabled");
    }
    return b_valid;
}
function on_verify_submit() {
    var data = JSON.parse(localStorage.getItem(g_userid));
    var u_edit_user = {};
    u_edit_user.userid = g_userid;
    u_edit_user.pwd = g_pwd;
    u_edit_user.name = data.name;
    u_edit_user.identity = data.identity;
    u_edit_user.address = data.address;
    u_edit_user.admin = data.admin;
    location.href="login.html";
    alert("保存成功！");
}
//全局变量
var g_userid,g_pwd,g_username;
var v_validata_userid=false;
var v_validata_pwd=false;
var checker=false;
var checkcode=false;
var g_admin=false;
//验证是否是本地存储过的，未存储过的不合法
function  foreach_userid(thisid) {
    var v_userid=document.getElementById(thisid).value;
    for(var i=0;i<localStorage.length;i++)
    {
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        if(v_userid==data.userid)
        {
            g_userid=v_userid;
            g_username=data.name;
            v_validata_userid=true;
            break;
        }
        else
            v_validata_userid=false;
    }
    return v_validata_userid;
}
//根据验证结果进行反馈
function on_userid_blur(thisid) {
    var v_userid=document.getElementById(thisid).value;
    if(v_userid=="")
    {
        document.getElementById('id-span-userid').innerHTML="input your user id";
    }
    else{
        if(foreach_userid(thisid)){
            document.getElementById('id-span-userid').innerHTML="your userid is right";
        }
        else {
            document.getElementById('id-span-userid').value='';
            document.getElementById('id-span-userid').innerHTML="check your userid please";
        }
    }
}
//是否有一个键值对是本用户名：本密码 防止同样键值存在
function foreach_pwd(pwd,userid) {
    var v_userid=document.getElementById(userid).value;
    var password=pwd;
    for(var i=0;i<localStorage.length;i++)
    {
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));
        if((v_userid==data.userid)&&(password==data.pwd))
        {
            g_userid=data.userid;
            g_pwd=data.pwd;
            v_validata_pwd=true;
            g_admin=data.admin;
            break;
        }
        else
        {
            v_validata_pwd=false;
        }
    }
    return v_validata_pwd;
}
//检验密码
function on_pwd_blur(thisid) {
    var v_password = document.getElementById(thisid).value;
    if (v_password == "") {
        document.getElementById('id-span-pwd').innerHTML = "input your password";
    }
    else {
        document.getElementById('id-span-pwd').innerHTML = "valid password";
        if (foreach_pwd(v_password, "userid")) {
            checker=true;
        }
        else {
            checker=false;
        }
    }
}
function on_check_blur(thisid) {//检查验证码是否正确
    var v_check=document.getElementById(thisid).value;
    if(v_check==document.getElementById("id-canvas").value)
        checkcode=true;
    else
        checkcode=false;
}
function on_login_submit() {
    var person={};
    person.userid=g_userid;
    person.name=g_username;
    if(!checkcode)
    {
        alert("验证码错误，请重新输入");
        document.getElementById("id-check").value="";
        return false;
    }
    if(checker)
    {
        if(!g_admin)//如果 不是管理员
        {
            document.getElementById("frm-login").setAttribute("action","edit.html");//修改跳转的页面
            alert("登陆成功");
        }
        else
            {
                document.getElementById("frm-login").setAttribute("action","admin.html");
            alert("大驾光临~管理员大大~");
        }
         sessionStorage.setItem("currentid",JSON.stringify(person));
    }
    else
    {
        document.getElementById("id-check").value="";//密码清空全部输入
        alert("密码错误");
        return false;
    }
}
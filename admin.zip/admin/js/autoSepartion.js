/*
* page divition (by id)
*
*/
    var allPages;
    var cnt;
    var indexs;
    var boxes;
    $(function() {//jq auto run when page loading is complete
		/*page divide*/
        var $div = $("#divPage");//the item
        var $pages = $("#page");//page who contine the item
        var pgindex = 1;//start from page '1' to page 'n'
        var eachCnt = 8;//how many items show in the page
        boxes = $("div[name='box']");//to count how many items there in total
        cnt = boxes.length;
        console.log(cnt);
        indexs = new Array(cnt);
        for(var i=0; i<cnt; i++) {
            indexs[i] = i;
        }
        allPages = Math.ceil(cnt/eachCnt);//count pages
        $pages.html("total" + allPages + "pages");//show how many pages
        console.log($pages);
        showPage(1);//start with page '1'
        for(var i=0; i<allPages; i++) {//show link of other pages (warnning, don't have too many pages for showing all page numbers here)
            $pages.append("<a href=\"javascript:showPage('"+ (i+1) +"');\"> "+ (i+1) +" </a>");
        }
        $pages.append("<a href=\"javascript:gotopage(-1);\">former</a> <a href=\"javascript:gotopage(1);\">next</a>");//two links goto upper page and next page
    });

    function gotopage(value){// goto page by 'value' (goto upper page or next page) 
        try{//-1(upper page) other(next page)
            value=="-1"?showPage(pgindex-1):showPage(pgindex+1);
        }catch(e){

        }
    }
    function showPage(pageIndex){//goto certain page
        if(pageIndex== 0 || pageIndex==(allPages+1)) {//judge whether 'pageIndex' is illegal
            return;
        }
        var start = (pageIndex-1)*8;//conculute box number of the first box in the page
        //alert("start:" + start);
        var end = start + 8;//conculute box number of the last box in the page
        end = end > cnt ? cnt : end;//judge how many boxes left in the page, if need to cut, cut it
        //alert("end:" + end);
        var subIndexs = indexs.slice(start, end);//show boxes from number 'start' to start + 8 (8 boxes in each page)
        for(var i=0; i<cnt; i++) {//show the boxes and hide the others
            if(contains(i, subIndexs)) {
                boxes.eq(i).show();
            }else{
                boxes.eq(i).hide();
            }
        }
        pgindex = pageIndex;
    }
    var contains = function (element, arr) {//judge whether the page number is in the collection of showed page numbers
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == element) {
                return true;
            }
        }
        return false;
    }

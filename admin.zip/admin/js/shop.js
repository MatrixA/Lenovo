var series;
var scale;
var year;
var colors;
var category;
var ids;
var money;
var all;
var texts;
var intel;
var navi;
var rand;
var image;
var classify;
var goods={};
var checkall;
window.onload =function app() {
    //向此id标签元素（表格）中覆盖如下html语句
    checkall=sessionStorage.getItem("series");
    document.getElementById("id-series").textContent=checkall;
    var sum=0;
    var kinds=0;
    var flag=false;
    var admin=document.getElementById("id-a").innerText;
    if(admin!="登录") {
        var u_id = JSON.parse(sessionStorage.getItem("currentid")).userid;
        var datas = JSON.parse(localStorage.getItem(u_id));
        var u_purchase = {};
        u_purchase.userid = "%" + datas.userid;
        u_purchase.name = datas.name;
        u_purchase.identity = datas.identity;
        u_purchase.address = datas.address;
        var own = JSON.parse(localStorage.getItem(u_purchase.userid));
        if (own == undefined) {
            kinds = 1;
            sum=0;
        }
        else {
            kinds = own.kind;
            for (var l = 0; l < kinds; l++) {
                sum += own.number[l];
            }
        }
        document.getElementById("id-buy").innerText = "购物车：" + sum + "件";
    }
    for(var i=0;i<localStorage.length;i++)
    {
        var keyer=localStorage.key(i);
        if(keyer.indexOf("_")==(-1))
        {
            continue;
        }
        var data=JSON.parse(localStorage.getItem(localStorage.key(i)));

        if(data.goodsid.slice(0,1)=="Z")
        {
            series="拯救者";
            category="游戏本";
        }
        else if (data.goodsid.slice(0,1)=="Y")
        {
            series="游侠";
            category="专业本";
        }
        else  if(data.goodsid.slice(0,1)=="X")
        {
            series="小新";
            category="家庭本";
        }
        else  if(data.goodsid.slice(0,1)=="E")
        {
            series="二合一";
            category="商务本";
        }
        else  if(data.goodsid.slice(0,1)=="A")
        {
            series="主机";
            category="台式机";
        }
        else  if(data.goodsid.slice(0,1)=="B")
        {
            series="Tinkpad";
            category="一体机";
        }
        else  if(data.goodsid.slice(0,1)=="C")
        {
            series="Surface";
            category="显示器";
        }
        else series="空";
        if(category!=checkall.slice(2,5))
            continue;
        year="20"+data.goodsid.slice(1,3)+"年上市";
        scale="1"+data.goodsid.slice(4,5)+"英寸";
        colors=data.goodsid.slice(5,6);
        if(colors=="B")
            colors="黑色";
        else
            colors="白色";
        norm=data.goodsid.slice(6,7);
        if(norm=="N")
            norm="非触屏";
        else norm="触屏";
        intel="酷睿i"+data.goodsid.slice(8,9);
        navi="GTX10"+data.goodsid.slice(10,12);
        nav="英伟达 "+navi;
        rand=data.goodsid.slice(13,15)+"g";
        ids=data.goodsid;
        goods[i]=ids;
        money=data.money;
        image="goodsImg/"+ids.slice(0,6)+".jpg";
        texts=series+" "+ids+" "+year+"\n"+scale+" "+category+" "+colors+"\n"+intel+" "+navi+" "+rand;
        classify=year+" "+intel+" "+navi;
        document.getElementById("portfolio-list").innerHTML +=
    "<li class = '"+classify+"'>"+
        "<div class = 'shopFrame'  name = 'box'>"+
        "<div class = 'imageArea'>"+
        "<a onclick='on_shift()'>"+
        "<img src = "+image+"/ width='100%' height='100%'>"+
        "</a>"+
        "</div>"+
        "<div class = 'wordArea'>"+
        "<h2 >"+ids+"</h2>"+
        "<p>"+texts+"</p>"+
        "<p>"+"系列："+series+"</p>"+
        "<p>"+"尺寸："+scale+"</p>"+
        "<p>"+"颜色："+colors+"</p>"+
        "<p>"+"标准："+norm+"</p>"+
        "<div class = 'classCan'>"+
        "<p>"+year+"</p>"+
        "<p>"+intel+"</p>"+
        "<p>"+nav+"</p>"+
        "</div>"+
        "</div>"+
        "<div id="+ids+"   onclick='on_buy(this.id)' class = 'btnPurchase' style=' cursor: pointer; position:relative;top: 40%'>"+
        "<a    > "+"¥"+money+ " "+"Buy"+
    "</a>"+
    "</div>"+
    "</div>"+
    "</li>"
    }

}
function  on_buy(thisid) {
    var data=JSON.parse(localStorage.getItem(thisid));
    sessionStorage.setItem("good",JSON.stringify(data));
    location.href="item.html";
}
window.onload =function app() {
    var ids =JSON.parse(sessionStorage.getItem("currentid"));
    if(ids!=undefined)
    {
        document.getElementById("id-a").innerText=ids.name;
    }
    var sum=0;
    var kinds=0;
    var flag=false;
    var admin=document.getElementById("id-a").innerText;
    if(admin!="登录") {
        var u_id = JSON.parse(sessionStorage.getItem("currentid")).userid;
        var datas = JSON.parse(localStorage.getItem(u_id));
        var u_purchase = {};
        u_purchase.userid = "%" + datas.userid;
        u_purchase.name = datas.name;
        u_purchase.identity = datas.identity;
        u_purchase.address = datas.address;
        var own = JSON.parse(localStorage.getItem(u_purchase.userid));
        if (own == undefined) {
            kinds = 1;
            sum=0;
        }
        else {
            kinds = own.kind;
            for (var l = 0; l < kinds; l++) {
                sum += own.number[l];
            }
        }
        document.getElementById("id-buy").innerText = "购物车：" + sum + "件";
    }
}
function on_shopping() {
    var ids =JSON.parse(sessionStorage.getItem("currentid"));
    if(ids==undefined)
    {
        alert("游客模式，请先登录");
    }
    else
    {
        location.href="shopping.html";
    }
}